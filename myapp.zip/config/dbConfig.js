module.exports = { 
  url : 'mongodb+srv://admin:sryk23Mongo@cluster0-hjsxy.gcp.mongodb.net/test?retryWrites=true&w=majority',
  dbName : 'reports'
}