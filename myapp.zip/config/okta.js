module.exports ={
  okta: 'e46F56hHKj27TzdZGxulimN1CQDy_iN_HGiHZh4u',
  oktaDomain: 'dev-275928.okta.com',
  client: '0oa2e996m5MQIRpZU357'
}