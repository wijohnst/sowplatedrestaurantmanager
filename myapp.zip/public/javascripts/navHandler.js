console.log('Running navHandler.js...')

const navContainer = document.querySelector('#nav-container');
console.log(navContainer);